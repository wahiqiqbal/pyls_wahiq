# Project Title

This Repository is part of an assignment of my course COMP350 "Software Design Practical" (T7).

## Getting Started

To copy this project, simply run "git clone https://github.com/wahiqiqbal/pyls_wahiq.git"

### Prerequisites

The things you need before installing the software.

* A working laptop OFC
* Python installed on your workstation
* Latest Pytest installed

If you have any further questions or suggestions, reach out to me on LinkedIn @wahiqq

Thankyou
